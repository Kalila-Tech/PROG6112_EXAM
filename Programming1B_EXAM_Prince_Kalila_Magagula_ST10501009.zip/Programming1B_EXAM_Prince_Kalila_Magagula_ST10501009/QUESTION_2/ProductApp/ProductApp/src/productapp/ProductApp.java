/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 * author Prince
 */
package productapp;

import java.awt.GridLayout;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.*;

public class ProductApp extends JFrame {

    // Declare the text fields, product list and button
    private final JTextField txtName = new JTextField(20);

    // Create a dropdown list of products
    private final JComboBox<String> cmbProduct = new JComboBox<>(new String[]{
        "Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"});

    private final JTextField txtPrice = new JTextField(20);
    private final JButton btnProcess = new JButton("PROCESS");

    // Constructor to create the application window
    public ProductApp() {
        super("Product App");

        // Close the application when the window is closed
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Create the menu bar
        buildMenu();

        // Create a panel with 4 rows and 2 columns
        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 15));

        // Add spacing around the panel
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Add labels and input fields to the panel
        panel.add(new JLabel("Customer Name:"));
        panel.add(txtName);

        panel.add(new JLabel("Select Product:"));
        panel.add(cmbProduct);

        panel.add(new JLabel("Enter Price:"));
        panel.add(txtPrice);

        panel.add(new JLabel(""));
        panel.add(btnProcess);

        // Add the panel to the window
        add(panel);

        // Call the process method when the button is clicked
        btnProcess.addActionListener(e -> process());

        // Adjust window size and position
        pack();
        setLocationRelativeTo(null);
    }

    // Method to create the File and Tools menus
    private void buildMenu() {

        JMenuBar bar = new JMenuBar();

        // Create the File menu
        JMenu file = new JMenu("File");

        // Create an Exit option
        JMenuItem exit = new JMenuItem("Exit");

        // Close the application when Exit is selected
        exit.addActionListener(e -> System.exit(0));
        file.add(exit);

        // Create the Tools menu
        JMenu tools = new JMenu("Tools");

        // Create the Process option
        JMenuItem process = new JMenuItem("Process");

        // Call the process method when selected
        process.addActionListener(e -> process());

        // Create the Clear option
        JMenuItem clear = new JMenuItem("Clear");

        // Call the clear method when selected
        clear.addActionListener(e -> clear());

        // Add options to the Tools menu
        tools.add(process);
        tools.add(clear);

        // Add menus to the menu bar
        bar.add(file);
        bar.add(tools);

        // Display the menu bar
        setJMenuBar(bar);
    }

    // Method to process customer and product information
    private void process() {

        // Get the customer name and selected product
        String name = txtName.getText().trim();
        String product = (String) cmbProduct.getSelectedItem();

        double price;

        // Check if the customer name is empty
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the customer name.");
            return;
        }

        // Check if the entered price is valid
        try {
            price = Double.parseDouble(txtPrice.getText().trim());

            // Prevent negative prices
            if (price < 0) throw new NumberFormatException();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid price.");
            return;
        }

        // Create an object to calculate VAT, commission and total
        IProductCalculations calc = new ProductCalculations(price);

        // Get the calculated values
        double vat = calc.GetVat();
        double commission = calc.GetCommission();
        double total = calc.GetTotal();

        // Display the customer and calculation details
        JOptionPane.showMessageDialog(this,
            "Customer Name: " + name + "\n"
            + "Product: " + product + "\n"
            + "VAT: R " + vat + "\n"
            + "COMMISSION: R " + commission + "\n"
            + "TOTAL: R " + total);

        // Save the information to a text file
        saveToFile(name, product, vat, commission, total);
    }

    // Method to save customer information to data.txt
    private void saveToFile(String name, String product, double vat, double commission, double total) {

        // Open the file in append mode so existing data is not deleted
        try (PrintWriter out = new PrintWriter(new FileWriter("data.txt", true))) {

            // Write customer and calculation details to the file
            out.println("DATA LOG");
            out.println("*".repeat(32));
            out.println("Customer Name: " + name);
            out.println("Product: " + product);
            out.println("VAT: R " + vat);
            out.println("COMMISSION: R " + commission);
            out.println("TOTAL: R " + total);
            out.println("*".repeat(32));
            out.println();

        } catch (IOException ex) {

            // Display an error message if the file cannot be saved
            JOptionPane.showMessageDialog(this, "Could not save to data.txt: " + ex.getMessage());
        }
    }

    // Method to clear all input fields
    private void clear() {

        txtName.setText("");
        txtPrice.setText("");

        // Reset the dropdown to the first product
        cmbProduct.setSelectedIndex(0);
    }

    // Main method that starts the application
    public static void main(String[] args) {

        // Run the application safely using Swing
        SwingUtilities.invokeLater(() -> new ProductApp().setVisible(true));
    }
}
