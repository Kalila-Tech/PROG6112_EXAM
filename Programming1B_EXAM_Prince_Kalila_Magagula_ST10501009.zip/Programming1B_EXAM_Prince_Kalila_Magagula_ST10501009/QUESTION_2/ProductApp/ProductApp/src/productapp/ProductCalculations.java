/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 * author Prince
 */

package productapp;

// Class responsible for calculating VAT, commission and total price
public class ProductCalculations implements IProductCalculations {

    // Set VAT rate to 15%
    private static final double VAT_RATE = 0.15;

    // Set commission rate to 5%
    private static final double COMMISSION_RATE = 0.05;

    // Variable to store the product price
    private final double price;

    // Constructor receives the product price
    public ProductCalculations(double price) {
        this.price = price;
    }

    // Method to calculate VAT
    @Override
    public double GetVat() {
        return price * VAT_RATE;
    }

    // Method to calculate commission
    @Override
    public double GetCommission() {
        return price * COMMISSION_RATE;
    }

    // Method to calculate the final total price
    @Override
    public double GetTotal() {
        return price + GetVat() + GetCommission();
    }
}
